modded class MissionGameplay
{
		

}