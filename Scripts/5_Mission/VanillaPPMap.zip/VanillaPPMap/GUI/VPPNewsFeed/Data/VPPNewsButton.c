class VPPNewsButton
{
	string Name;
	string BtnIcon;
	string Url;
	
	void VPPNewsButton(){}
};