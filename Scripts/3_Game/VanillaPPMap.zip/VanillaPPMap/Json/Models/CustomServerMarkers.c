class CustomServerMarkers {
    string addressPort = "";
    ref array<ref MarkerInfo> serverMarkers = new array<ref MarkerInfo>;
}