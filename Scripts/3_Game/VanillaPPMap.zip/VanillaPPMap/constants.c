static const int VPP_MENU_MAP  = 3815265483;
static const int VPP_MENU_EDIT_DIALOG  = 3815265484;